# PrescriptiveAnalysis
Prescriptive Analysis - An introductory course, specially developed for the WCDBDA - 2019
Link presentation : https://docs.google.com/presentation/d/18KYVtoIVcdJWneIWvcH-APMR4mEkwwEFNdggOKjHGIM/edit?usp=sharing
Sorry, but the whole material is in Portuguese
